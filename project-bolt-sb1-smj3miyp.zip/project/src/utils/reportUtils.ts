import { TimerSession, TimerReport, ExportOptions } from '../types/timer';

export const generateReport = (sessions: TimerSession[]): TimerReport => {
  const completedSessions = sessions.filter(s => s.status === 'completed');
  const totalTime = completedSessions.reduce((sum, session) => sum + session.duration, 0);
  const totalSessions = sessions.length;
  const averageSessionDuration = completedSessions.length > 0 
    ? Math.floor(totalTime / completedSessions.length) 
    : 0;

  // Daily breakdown
  const dailyMap = new Map<string, { duration: number; sessions: number }>();
  completedSessions.forEach(session => {
    const date = session.startTime.toISOString().split('T')[0];
    const existing = dailyMap.get(date) || { duration: 0, sessions: 0 };
    dailyMap.set(date, {
      duration: existing.duration + session.duration,
      sessions: existing.sessions + 1
    });
  });

  const dailyBreakdown = Array.from(dailyMap.entries())
    .map(([date, data]) => ({ date, ...data }))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Weekly breakdown
  const weeklyMap = new Map<string, { duration: number; sessions: number }>();
  completedSessions.forEach(session => {
    const date = new Date(session.startTime);
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    const weekKey = weekStart.toISOString().split('T')[0];
    
    const existing = weeklyMap.get(weekKey) || { duration: 0, sessions: 0 };
    weeklyMap.set(weekKey, {
      duration: existing.duration + session.duration,
      sessions: existing.sessions + 1
    });
  });

  const weeklyBreakdown = Array.from(weeklyMap.entries())
    .map(([week, data]) => ({ week, ...data }))
    .sort((a, b) => new Date(b.week).getTime() - new Date(a.week).getTime());

  // Monthly breakdown
  const monthlyMap = new Map<string, { duration: number; sessions: number }>();
  completedSessions.forEach(session => {
    const date = new Date(session.startTime);
    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    
    const existing = monthlyMap.get(monthKey) || { duration: 0, sessions: 0 };
    monthlyMap.set(monthKey, {
      duration: existing.duration + session.duration,
      sessions: existing.sessions + 1
    });
  });

  const monthlyBreakdown = Array.from(monthlyMap.entries())
    .map(([month, data]) => ({ month, ...data }))
    .sort((a, b) => b.month.localeCompare(a.month));

  return {
    totalTime,
    totalSessions,
    completedSessions: completedSessions.length,
    averageSessionDuration,
    dailyBreakdown,
    weeklyBreakdown,
    monthlyBreakdown
  };
};

export const exportToCSV = (sessions: TimerSession[], options: ExportOptions): string => {
  let filteredSessions = sessions;
  
  if (options.dateRange !== 'all') {
    const now = new Date();
    let startDate: Date;
    
    switch (options.dateRange) {
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case 'custom':
        startDate = options.startDate || new Date(0);
        break;
      default:
        startDate = new Date(0);
    }
    
    const endDate = options.endDate || now;
    filteredSessions = sessions.filter(session => 
      session.startTime >= startDate && session.startTime <= endDate
    );
  }

  const headers = ['Date', 'Start Time', 'End Time', 'Duration (HH:MM:SS)', 'Status', 'Paused Duration (HH:MM:SS)'];
  const rows = filteredSessions.map(session => [
    session.startTime.toLocaleDateString(),
    session.startTime.toLocaleTimeString(),
    session.endTime?.toLocaleTimeString() || 'N/A',
    formatDuration(session.duration),
    session.status,
    formatDuration(session.pausedDuration)
  ]);

  return [headers, ...rows].map(row => row.join(',')).join('\n');
};

export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
};

export const formatTime = (seconds: number): string => {
  return formatDuration(seconds);
};

export const downloadFile = (content: string, filename: string, type: string) => {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};