import React from 'react';
import { Clock, Calendar, CheckCircle, PauseCircle, XCircle } from 'lucide-react';
import { TimerSession } from '../types/timer';
import { formatTime } from '../utils/reportUtils';

interface RecentSessionsProps {
  sessions: TimerSession[];
  onClearAll: () => void;
}

export const RecentSessions: React.FC<RecentSessionsProps> = ({ sessions, onClearAll }) => {
  const getStatusIcon = (status: TimerSession['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'paused':
        return <PauseCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <XCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getStatusText = (status: TimerSession['status']) => {
    switch (status) {
      case 'completed':
        return 'Completed';
      case 'paused':
        return 'Paused';
      default:
        return 'Stopped';
    }
  };

  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center">
          <Clock className="w-7 h-7 mr-3 text-blue-500" />
          Recent Sessions
        </h2>
        {sessions.length > 0 && (
          <button
            onClick={onClearAll}
            className="px-4 py-2 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors font-medium"
          >
            Clear All
          </button>
        )}
      </div>

      {sessions.length === 0 ? (
        <div className="text-center py-12">
          <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">No timer sessions yet</p>
          <p className="text-gray-400 text-sm">Start your first timer to see sessions here</p>
        </div>
      ) : (
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {sessions.slice(0, 10).map((session) => (
            <div
              key={session.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center space-x-4">
                {getStatusIcon(session.status)}
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-600">
                      {formatDateTime(session.startTime)}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {getStatusText(session.status)}
                    {session.pausedDuration > 0 && (
                      <span className="ml-2">
                        (Paused: {formatTime(session.pausedDuration)})
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-xl font-mono font-bold text-gray-800">
                  {formatTime(session.duration)}
                </div>
                {session.endTime && (
                  <div className="text-xs text-gray-500">
                    Ended: {session.endTime.toLocaleTimeString()}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};