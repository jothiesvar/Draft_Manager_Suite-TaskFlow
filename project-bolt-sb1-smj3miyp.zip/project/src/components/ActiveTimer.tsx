import React from 'react';
import { Play, Square } from 'lucide-react';
import { formatTime } from '../utils/timeUtils';
import { Task } from '../types';

interface ActiveTimerProps {
  time: number;
  isRunning: boolean;
  selectedTask: string;
  tasks: Task[];
  onStart: () => void;
  onStop: () => void;
  onTaskChange: (taskId: string) => void;
}

export const ActiveTimer: React.FC<ActiveTimerProps> = ({
  time,
  isRunning,
  selectedTask,
  tasks,
  onStart,
  onStop,
  onTaskChange
}) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Active Timer</h2>
      
      <div className="text-center mb-8">
        <div className="text-7xl font-mono font-bold text-gray-900 mb-6 tracking-wider">
          {formatTime(time)}
        </div>
        
        <select
          value={selectedTask}
          onChange={(e) => onTaskChange(e.target.value)}
          className="w-full max-w-md px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-lg mb-6"
        >
          <option value="">Select a task...</option>
          {tasks.map((task) => (
            <option key={task.id} value={task.id}>
              {task.name} - {task.client}
            </option>
          ))}
        </select>
        
        <div className="flex justify-center space-x-4">
          <button
            onClick={onStart}
            disabled={!selectedTask || isRunning}
            className="flex items-center px-8 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium"
          >
            <Play className="w-5 h-5 mr-2" />
            Start
          </button>
          
          <button
            onClick={onStop}
            disabled={!isRunning}
            className="flex items-center px-8 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium"
          >
            <Square className="w-5 h-5 mr-2" />
            Stop
          </button>
        </div>
      </div>
    </div>
  );
};