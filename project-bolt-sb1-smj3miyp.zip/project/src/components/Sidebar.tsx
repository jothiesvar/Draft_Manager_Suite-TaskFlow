import React from 'react';
import { 
  Home, 
  Users, 
  UserPlus, 
  CheckSquare, 
  FileText, 
  Calendar, 
  Clock, 
  BarChart3, 
  Settings 
} from 'lucide-react';

interface SidebarProps {
  activeItem: string;
  onItemClick: (item: string) => void;
}

const sidebarItems = [
  { id: 'dashboard', icon: Home, label: 'Dashboard' },
  { id: 'clients', icon: Users, label: 'Clients' },
  { id: 'leads', icon: UserPlus, label: 'Leads' },
  { id: 'tasks', icon: CheckSquare, label: 'Tasks' },
  { id: 'invoices', icon: FileText, label: 'Invoices' },
  { id: 'calendar', icon: Calendar, label: 'Calendar' },
  { id: 'time-tracking', icon: Clock, label: 'Time Tracking' },
  { id: 'reports', icon: BarChart3, label: 'Reports' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeItem, onItemClick }) => {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">ClientFlow</h1>
        <p className="text-sm text-gray-600">Management Suite</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeItem === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-colors ${
                isActive 
                  ? 'bg-orange-50 text-orange-600 border-r-2 border-orange-500' 
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
};