import React from 'react';
import { formatCurrency, formatDuration } from '../utils/timeUtils';
import { TimeEntry } from '../types';

interface RecentTimeEntriesProps {
  entries: TimeEntry[];
}

export const RecentTimeEntries: React.FC<RecentTimeEntriesProps> = ({ entries }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Recent Time Entries</h2>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Task
              </th>
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Client
              </th>
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Date
              </th>
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Duration
              </th>
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Rate
              </th>
              <th className="text-left py-4 px-2 text-sm font-medium text-gray-600 uppercase tracking-wider">
                Total
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {entries.map((entry) => (
              <tr key={entry.id} className="hover:bg-gray-50 transition-colors">
                <td className="py-4 px-2">
                  <div className="font-medium text-gray-900">{entry.task}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="text-gray-700">{entry.client}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="text-gray-700">{formatDate(entry.date)}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="font-mono text-gray-900">{formatDuration(entry.duration)}</div>
                </td>
                <td className="py-4 px-2">
                  <div className="text-gray-700">{formatCurrency(entry.rate)}/hr</div>
                </td>
                <td className="py-4 px-2">
                  <div className="font-medium text-gray-900">{formatCurrency(entry.total)}</div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};