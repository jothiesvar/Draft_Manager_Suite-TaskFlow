import React from 'react';
import { formatTime } from '../utils/reportUtils';
import { TimerState } from '../types/timer';

interface TimerDisplayProps {
  time: number;
  timerState: TimerState;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({ time, timerState }) => {
  const getStatusColor = () => {
    switch (timerState) {
      case 'running':
        return 'text-green-500';
      case 'paused':
        return 'text-yellow-500';
      default:
        return 'text-gray-700';
    }
  };

  const getStatusText = () => {
    switch (timerState) {
      case 'running':
        return 'Running';
      case 'paused':
        return 'Paused';
      default:
        return 'Ready';
    }
  };

  return (
    <div className="text-center mb-8">
      <div className="relative">
        <div className="text-8xl font-mono font-bold text-gray-800 mb-4 tracking-wider">
          {formatTime(time)}
        </div>
        {timerState === 'running' && (
          <div className="absolute -top-2 -right-2">
            <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
          </div>
        )}
      </div>
      <div className={`text-2xl font-semibold ${getStatusColor()} mb-2`}>
        {getStatusText()}
      </div>
      {timerState === 'paused' && (
        <div className="text-sm text-gray-500">
          Timer is paused - click Resume to continue
        </div>
      )}
    </div>
  );
};