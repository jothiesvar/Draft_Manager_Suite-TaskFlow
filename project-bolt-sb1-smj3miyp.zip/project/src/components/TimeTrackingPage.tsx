import React, { useState } from 'react';
import { ActiveTimer } from './ActiveTimer';
import { TodaysSummary } from './TodaysSummary';
import { RecentTimeEntries } from './RecentTimeEntries';
import { useTimer } from '../hooks/useTimer';
import { mockTasks, mockTimeEntries, mockTodaysSummary } from '../data/mockData';

export const TimeTrackingPage: React.FC = () => {
  const { time, isRunning, start, stop, reset } = useTimer();
  const [selectedTask, setSelectedTask] = useState('');

  const handleStart = () => {
    if (selectedTask) {
      start();
    }
  };

  const handleStop = () => {
    stop();
    // Here you would typically save the time entry
    console.log('Time entry saved:', {
      taskId: selectedTask,
      duration: time,
      date: new Date().toISOString().split('T')[0]
    });
  };

  const handleTaskChange = (taskId: string) => {
    setSelectedTask(taskId);
    if (isRunning) {
      stop();
      reset();
    }
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <ActiveTimer
            time={time}
            isRunning={isRunning}
            selectedTask={selectedTask}
            tasks={mockTasks}
            onStart={handleStart}
            onStop={handleStop}
            onTaskChange={handleTaskChange}
          />
        </div>
        
        <div>
          <TodaysSummary summary={mockTodaysSummary} />
        </div>
      </div>
      
      <RecentTimeEntries entries={mockTimeEntries} />
    </div>
  );
};