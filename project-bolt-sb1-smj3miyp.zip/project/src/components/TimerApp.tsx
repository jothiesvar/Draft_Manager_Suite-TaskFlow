import React, { useState } from 'react';
import { Timer, FileText } from 'lucide-react';
import { TimerDisplay } from './TimerDisplay';
import { TimerControls } from './TimerControls';
import { RecentSessions } from './RecentSessions';
import { ReportModal } from './ReportModal';
import { useAdvancedTimer } from '../hooks/useAdvancedTimer';
import { generateReport } from '../utils/reportUtils';

export const TimerApp: React.FC = () => {
  const {
    currentTime,
    timerState,
    sessions,
    start,
    pause,
    resume,
    stop,
    reset,
    clearAllSessions
  } = useAdvancedTimer();

  const [showReportModal, setShowReportModal] = useState(false);

  const handleGenerateReport = () => {
    setShowReportModal(true);
  };

  const report = generateReport(sessions);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Timer className="w-12 h-12 text-blue-500 mr-4" />
            <h1 className="text-4xl font-bold text-gray-900">Advanced Timer</h1>
          </div>
          <p className="text-gray-600 text-lg">Professional time tracking with detailed reporting</p>
        </div>

        {/* Main Timer Section */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-12">
            <TimerDisplay time={currentTime} timerState={timerState} />
            <TimerControls
              timerState={timerState}
              onStart={start}
              onPause={pause}
              onResume={resume}
              onStop={stop}
              onReset={reset}
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center mb-12">
          <button
            onClick={handleGenerateReport}
            className="flex items-center px-8 py-4 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
          >
            <FileText className="w-6 h-6 mr-3" />
            Generate Report
          </button>
        </div>

        {/* Recent Sessions */}
        <div className="max-w-4xl mx-auto">
          <RecentSessions sessions={sessions} onClearAll={clearAllSessions} />
        </div>

        {/* Report Modal */}
        <ReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          report={report}
          sessions={sessions}
        />
      </div>
    </div>
  );
};