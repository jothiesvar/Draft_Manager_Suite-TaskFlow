import React from 'react';
import { Play, Pause, Square, RotateCcw } from 'lucide-react';
import { TimerState } from '../types/timer';

interface TimerControlsProps {
  timerState: TimerState;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onReset: () => void;
}

export const TimerControls: React.FC<TimerControlsProps> = ({
  timerState,
  onStart,
  onPause,
  onResume,
  onStop,
  onReset
}) => {
  return (
    <div className="flex justify-center space-x-4 mt-8">
      {timerState === 'idle' && (
        <button
          onClick={onStart}
          className="flex items-center px-8 py-4 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
        >
          <Play className="w-6 h-6 mr-3" />
          Start Timer
        </button>
      )}
      
      {timerState === 'running' && (
        <>
          <button
            onClick={onPause}
            className="flex items-center px-8 py-4 bg-yellow-500 text-white rounded-xl hover:bg-yellow-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
          >
            <Pause className="w-6 h-6 mr-3" />
            Pause
          </button>
          <button
            onClick={onStop}
            className="flex items-center px-8 py-4 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
          >
            <Square className="w-6 h-6 mr-3" />
            Stop
          </button>
        </>
      )}
      
      {timerState === 'paused' && (
        <>
          <button
            onClick={onResume}
            className="flex items-center px-8 py-4 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
          >
            <Play className="w-6 h-6 mr-3" />
            Resume
          </button>
          <button
            onClick={onStop}
            className="flex items-center px-8 py-4 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
          >
            <Square className="w-6 h-6 mr-3" />
            Stop
          </button>
        </>
      )}
      
      {timerState !== 'idle' && (
        <button
          onClick={onReset}
          className="flex items-center px-6 py-4 bg-gray-500 text-white rounded-xl hover:bg-gray-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
        >
          <RotateCcw className="w-5 h-5 mr-2" />
          Reset
        </button>
      )}
    </div>
  );
};