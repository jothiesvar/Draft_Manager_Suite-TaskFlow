import React, { useState } from 'react';
import { X, Download, BarChart3, Calendar, Clock, Users } from 'lucide-react';
import { TimerReport, ExportOptions } from '../types/timer';
import { formatTime, exportToCSV, downloadFile } from '../utils/reportUtils';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: TimerReport;
  sessions: any[];
}

export const ReportModal: React.FC<ReportModalProps> = ({ 
  isOpen, 
  onClose, 
  report,
  sessions 
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'daily' | 'weekly' | 'monthly'>('overview');
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    format: 'csv',
    dateRange: 'all'
  });

  if (!isOpen) return null;

  const handleExport = () => {
    if (exportOptions.format === 'csv') {
      const csvContent = exportToCSV(sessions, exportOptions);
      const filename = `timer-report-${new Date().toISOString().split('T')[0]}.csv`;
      downloadFile(csvContent, filename, 'text/csv');
    }
  };

  const formatPercentage = (value: number, total: number) => {
    return total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <BarChart3 className="w-7 h-7 mr-3 text-blue-500" />
            Timer Report
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-500" />
          </button>
        </div>

        <div className="flex border-b border-gray-200">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'daily', label: 'Daily', icon: Calendar },
            { id: 'weekly', label: 'Weekly', icon: Calendar },
            { id: 'monthly', label: 'Monthly', icon: Calendar }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-6 py-4 font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-blue-50 rounded-xl p-6 text-center">
                  <Clock className="w-8 h-8 text-blue-500 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-blue-600 mb-1">
                    {formatTime(report.totalTime)}
                  </div>
                  <div className="text-sm text-blue-700 font-medium">Total Time</div>
                </div>
                
                <div className="bg-green-50 rounded-xl p-6 text-center">
                  <Users className="w-8 h-8 text-green-500 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-green-600 mb-1">
                    {report.totalSessions}
                  </div>
                  <div className="text-sm text-green-700 font-medium">Total Sessions</div>
                </div>
                
                <div className="bg-purple-50 rounded-xl p-6 text-center">
                  <BarChart3 className="w-8 h-8 text-purple-500 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-purple-600 mb-1">
                    {report.completedSessions}
                  </div>
                  <div className="text-sm text-purple-700 font-medium">Completed</div>
                </div>
                
                <div className="bg-orange-50 rounded-xl p-6 text-center">
                  <Clock className="w-8 h-8 text-orange-500 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-orange-600 mb-1">
                    {formatTime(report.averageSessionDuration)}
                  </div>
                  <div className="text-sm text-orange-700 font-medium">Average</div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Session Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Completion Rate</span>
                    <span className="font-semibold text-gray-900">
                      {formatPercentage(report.completedSessions, report.totalSessions)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Longest Session</span>
                    <span className="font-semibold text-gray-900">
                      {sessions.length > 0 
                        ? formatTime(Math.max(...sessions.map(s => s.duration)))
                        : '00:00:00'
                      }
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Shortest Session</span>
                    <span className="font-semibold text-gray-900">
                      {sessions.length > 0 
                        ? formatTime(Math.min(...sessions.filter(s => s.duration > 0).map(s => s.duration)))
                        : '00:00:00'
                      }
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'daily' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Daily Breakdown</h3>
              {report.dailyBreakdown.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No daily data available</p>
              ) : (
                <div className="space-y-3">
                  {report.dailyBreakdown.map((day) => (
                    <div key={day.date} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-gray-900">
                          {new Date(day.date).toLocaleDateString('en-US', { 
                            weekday: 'long', 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </div>
                        <div className="text-sm text-gray-600">{day.sessions} sessions</div>
                      </div>
                      <div className="text-xl font-mono font-bold text-gray-800">
                        {formatTime(day.duration)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'weekly' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Weekly Breakdown</h3>
              {report.weeklyBreakdown.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No weekly data available</p>
              ) : (
                <div className="space-y-3">
                  {report.weeklyBreakdown.map((week) => (
                    <div key={week.week} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-gray-900">
                          Week of {new Date(week.week).toLocaleDateString()}
                        </div>
                        <div className="text-sm text-gray-600">{week.sessions} sessions</div>
                      </div>
                      <div className="text-xl font-mono font-bold text-gray-800">
                        {formatTime(week.duration)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'monthly' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Monthly Breakdown</h3>
              {report.monthlyBreakdown.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No monthly data available</p>
              ) : (
                <div className="space-y-3">
                  {report.monthlyBreakdown.map((month) => (
                    <div key={month.month} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-gray-900">
                          {new Date(month.month + '-01').toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long' 
                          })}
                        </div>
                        <div className="text-sm text-gray-600">{month.sessions} sessions</div>
                      </div>
                      <div className="text-xl font-mono font-bold text-gray-800">
                        {formatTime(month.duration)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <select
                value={exportOptions.format}
                onChange={(e) => setExportOptions(prev => ({ ...prev, format: e.target.value as 'csv' | 'pdf' }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="csv">CSV Format</option>
                <option value="pdf" disabled>PDF Format (Coming Soon)</option>
              </select>
              
              <select
                value={exportOptions.dateRange}
                onChange={(e) => setExportOptions(prev => ({ ...prev, dateRange: e.target.value as any }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Time</option>
                <option value="week">Last Week</option>
                <option value="month">Last Month</option>
              </select>
            </div>
            
            <button
              onClick={handleExport}
              className="flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium"
            >
              <Download className="w-5 h-5 mr-2" />
              Export Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};