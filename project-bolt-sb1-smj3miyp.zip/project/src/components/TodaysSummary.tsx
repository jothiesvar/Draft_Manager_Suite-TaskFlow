import React from 'react';
import { formatTime, formatDuration } from '../utils/timeUtils';
import { TodaysSummary as TodaysSummaryType } from '../types';

interface TodaysSummaryProps {
  summary: TodaysSummaryType;
}

export const TodaysSummary: React.FC<TodaysSummaryProps> = ({ summary }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Today's Summary</h2>
      
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div className="text-center">
          <div className="text-4xl font-bold text-orange-500 mb-2">
            {formatTime(summary.totalTime)}
          </div>
          <p className="text-gray-600 font-medium">Total Time</p>
        </div>
        
        <div className="text-center">
          <div className="text-4xl font-bold text-green-500 mb-2">
            {summary.totalTasks}
          </div>
          <p className="text-gray-600 font-medium">Tasks</p>
        </div>
      </div>
      
      <div className="space-y-4">
        {summary.taskBreakdown.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <h3 className="font-medium text-gray-900">{item.task}</h3>
              <p className="text-sm text-gray-600">{item.client}</p>
            </div>
            <div className="text-right">
              <p className="font-mono font-medium text-gray-900">
                {formatDuration(item.duration)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};