import React from 'react';
import { TimerApp } from './components/TimerApp';

function App() {
  return <TimerApp />;
}

export default App;