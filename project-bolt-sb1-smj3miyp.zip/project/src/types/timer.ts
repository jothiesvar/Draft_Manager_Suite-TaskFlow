export interface TimerSession {
  id: string;
  startTime: Date;
  endTime?: Date;
  duration: number; // in seconds
  status: 'running' | 'paused' | 'completed' | 'stopped';
  pausedDuration: number; // total time paused in seconds
  pauseHistory: { pausedAt: Date; resumedAt?: Date }[];
}

export interface TimerReport {
  totalTime: number;
  totalSessions: number;
  completedSessions: number;
  averageSessionDuration: number;
  dailyBreakdown: { date: string; duration: number; sessions: number }[];
  weeklyBreakdown: { week: string; duration: number; sessions: number }[];
  monthlyBreakdown: { month: string; duration: number; sessions: number }[];
}

export type TimerState = 'idle' | 'running' | 'paused';

export interface ExportOptions {
  format: 'csv' | 'pdf';
  dateRange: 'all' | 'week' | 'month' | 'custom';
  startDate?: Date;
  endDate?: Date;
}