export interface TimeEntry {
  id: string;
  task: string;
  client: string;
  date: string;
  duration: number; // in seconds
  rate: number;
  total: number;
  isActive?: boolean;
}

export interface Task {
  id: string;
  name: string;
  client: string;
  isActive?: boolean;
}

export interface TodaysSummary {
  totalTime: number;
  totalTasks: number;
  taskBreakdown: {
    task: string;
    client: string;
    duration: number;
  }[];
}

export interface User {
  name: string;
  role: string;
  avatar?: string;
}