import { TimeEntry, Task, TodaysSummary, User } from '../types';

export const mockTasks: Task[] = [
  { id: '1', name: 'Website Redesign', client: 'Tech Solutions Inc.' },
  { id: '2', name: 'Database Migration', client: 'Digital Marketing Pro' },
  { id: '3', name: 'Mobile App Testing', client: 'Tech Solutions Inc.' },
  { id: '4', name: 'API Development', client: 'StartupXYZ' },
  { id: '5', name: 'UI/UX Review', client: 'Creative Agency' },
];

export const mockTimeEntries: TimeEntry[] = [
  {
    id: '1',
    task: 'Website Redesign',
    client: 'Tech Solutions Inc.',
    date: '2024-12-20',
    duration: 7200, // 2 hours
    rate: 75,
    total: 150
  },
  {
    id: '2',
    task: 'Database Migration',
    client: 'Digital Marketing Pro',
    date: '2024-12-20',
    duration: 10800, // 3 hours
    rate: 85,
    total: 255
  },
  {
    id: '3',
    task: 'Mobile App Testing',
    client: 'Tech Solutions Inc.',
    date: '2024-12-20',
    duration: 5400, // 1.5 hours
    rate: 70,
    total: 105
  },
  {
    id: '4',
    task: 'API Development',
    client: 'StartupXYZ',
    date: '2024-12-19',
    duration: 14400, // 4 hours
    rate: 90,
    total: 360
  },
  {
    id: '5',
    task: 'UI/UX Review',
    client: 'Creative Agency',
    date: '2024-12-19',
    duration: 3600, // 1 hour
    rate: 80,
    total: 80
  },
];

export const mockTodaysSummary: TodaysSummary = {
  totalTime: 25200, // 7 hours
  totalTasks: 4,
  taskBreakdown: [
    { task: 'Website Redesign', client: 'Tech Solutions Inc.', duration: 7200 },
    { task: 'Database Migration', client: 'Digital Marketing Pro', duration: 10800 },
    { task: 'Mobile App Testing', client: 'Tech Solutions Inc.', duration: 5400 },
    { task: 'API Development', client: 'StartupXYZ', duration: 1800 },
  ]
};

export const mockUser: User = {
  name: 'John Doe',
  role: 'Administrator'
};