import { useState, useEffect, useRef, useCallback } from 'react';
import { TimerSession, TimerState } from '../types/timer';

export const useAdvancedTimer = () => {
  const [currentTime, setCurrentTime] = useState(0);
  const [timerState, setTimerState] = useState<TimerState>('idle');
  const [currentSession, setCurrentSession] = useState<TimerSession | null>(null);
  const [sessions, setSessions] = useState<TimerSession[]>(() => {
    const saved = localStorage.getItem('timerSessions');
    return saved ? JSON.parse(saved) : [];
  });
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<Date | null>(null);
  const pauseStartRef = useRef<Date | null>(null);

  // Save sessions to localStorage whenever sessions change
  useEffect(() => {
    localStorage.setItem('timerSessions', JSON.stringify(sessions));
  }, [sessions]);

  // Timer tick effect
  useEffect(() => {
    if (timerState === 'running') {
      intervalRef.current = setInterval(() => {
        setCurrentTime(prev => prev + 1);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerState]);

  const start = useCallback(() => {
    const now = new Date();
    startTimeRef.current = now;
    
    const newSession: TimerSession = {
      id: crypto.randomUUID(),
      startTime: now,
      duration: 0,
      status: 'running',
      pausedDuration: 0,
      pauseHistory: []
    };
    
    setCurrentSession(newSession);
    setCurrentTime(0);
    setTimerState('running');
  }, []);

  const pause = useCallback(() => {
    if (timerState === 'running' && currentSession) {
      const now = new Date();
      pauseStartRef.current = now;
      
      const updatedSession = {
        ...currentSession,
        status: 'paused' as const,
        duration: currentTime,
        pauseHistory: [
          ...currentSession.pauseHistory,
          { pausedAt: now }
        ]
      };
      
      setCurrentSession(updatedSession);
      setTimerState('paused');
    }
  }, [timerState, currentSession, currentTime]);

  const resume = useCallback(() => {
    if (timerState === 'paused' && currentSession && pauseStartRef.current) {
      const now = new Date();
      const pauseDuration = Math.floor((now.getTime() - pauseStartRef.current.getTime()) / 1000);
      
      const updatedPauseHistory = [...currentSession.pauseHistory];
      const lastPause = updatedPauseHistory[updatedPauseHistory.length - 1];
      if (lastPause && !lastPause.resumedAt) {
        lastPause.resumedAt = now;
      }
      
      const updatedSession = {
        ...currentSession,
        status: 'running' as const,
        pausedDuration: currentSession.pausedDuration + pauseDuration,
        pauseHistory: updatedPauseHistory
      };
      
      setCurrentSession(updatedSession);
      setTimerState('running');
      pauseStartRef.current = null;
    }
  }, [timerState, currentSession]);

  const stop = useCallback(() => {
    if (currentSession && (timerState === 'running' || timerState === 'paused')) {
      const now = new Date();
      let finalPausedDuration = currentSession.pausedDuration;
      
      // If stopping while paused, add the current pause duration
      if (timerState === 'paused' && pauseStartRef.current) {
        const currentPauseDuration = Math.floor((now.getTime() - pauseStartRef.current.getTime()) / 1000);
        finalPausedDuration += currentPauseDuration;
      }
      
      const completedSession: TimerSession = {
        ...currentSession,
        endTime: now,
        duration: currentTime,
        status: 'completed',
        pausedDuration: finalPausedDuration
      };
      
      setSessions(prev => [completedSession, ...prev]);
      setCurrentSession(null);
      setCurrentTime(0);
      setTimerState('idle');
      pauseStartRef.current = null;
    }
  }, [currentSession, currentTime, timerState]);

  const reset = useCallback(() => {
    setCurrentSession(null);
    setCurrentTime(0);
    setTimerState('idle');
    startTimeRef.current = null;
    pauseStartRef.current = null;
  }, []);

  const clearAllSessions = useCallback(() => {
    setSessions([]);
    localStorage.removeItem('timerSessions');
  }, []);

  return {
    currentTime,
    timerState,
    currentSession,
    sessions,
    start,
    pause,
    resume,
    stop,
    reset,
    clearAllSessions
  };
};